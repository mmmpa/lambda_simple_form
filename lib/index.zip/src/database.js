exports.database = {
  region: "us-west-2",
  endpoint: "http://localhost:8000",
  tableName: 'lambda_simple_form_test'
};
